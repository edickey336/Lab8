/*******************************************************
filename: Problem1.cpp
Author: Emily Dickey on 04/15/2021.
Description: Time Class Method Implementation
*******************************************************/

#include <iostream>
#include <string>
#include "DateTime.cpp"
#include <chrono>
#include <thread>

using namespace std;

int main (){
    DateTime dt;

   // for (int i=0; i <5; i++ ){
        cout << "Today's Date is: " << dt.getDateStr() << endl;
        cout << "Double check: " << dt.month() << "/" << dt.day() << "/" << dt.year() << endl;
        cout << "The time is: " << dt.getTimeStr() << endl;
        cout << "Double check: " << dt.hour() << ":" << dt.min() << ":" << dt.sec() << endl;
        cout << "The time in 24-hour format is: " << dt.getTimeStr24();
//        this_thread::sleep_for(std::chrono::milliseconds(1000));
  //  }

    return 0;
}

