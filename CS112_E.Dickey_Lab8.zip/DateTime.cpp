/*******************************************************
filename: DateTime.cpp
Author: Emily Dickey on 04/15/2021.
Description: Time Class
*******************************************************/

#include <string>
#include <ctime>

using namespace std;

class DateTime {
public:
       int year() {
           time_t t = time(0);
           tm *local_time = localtime(&t);
           return 1900 + local_time->tm_year;
       }

       int day() {
           time_t t = time(0);
           tm *local_time = localtime(&t);
           return local_time->tm_mday;
       }

       int month() {
           time_t t = time(0);
           tm *local_time = localtime(&t);
           return 1 + local_time->tm_mon;
       }

        std::string getDateStr(){
            time_t t = time(0);
            tm *local_time = localtime(&t);
            return std::to_string(1 + local_time->tm_mon) + "/" +
            std::to_string (local_time->tm_mday) + "/" +
            std::to_string(1900 + local_time->tm_year);
        }

           std:: string getTimeStr24() {
               time_t t = time(0);
               tm *local_time = localtime(&t);
               return std:: to_string(local_time->tm_hour)+ ":" +
                      std::to_string (local_time->tm_min) + ":" +
                      std::to_string (local_time->tm_sec);
           }

           std:: string getTimeStr() {
               time_t t = time(0);
               tm *local_time = localtime(&t);
               int hr = local_time->tm_hour;
               if (hr>12) {
                   return to_string(hr - 12) + ":" +
                          to_string (local_time->tm_min) + ":" +
                          std::to_string (local_time->tm_sec) + " pm";
               } else {
                   return to_string(hr) + ":" +
                   to_string (local_time->tm_min) + ":" +
                   std::to_string (local_time->tm_sec) + " am";
               }
           }

           string hour() {
               time_t t = time(0);
               tm *local_time = localtime(&t);
               int hr = local_time->tm_hour;
               if (hr>12) {
                   return to_string(hr - 12);
               } else {
                   return to_string(hr);
               }
           }

            int min() {
                time_t t = time(0);
                tm *local_time = localtime(&t);
                int min = local_time->tm_min;
                if (min<=59) {
                    return min;
                } return 0;
            }

            int sec() {
                time_t t = time(0);
                tm *local_time = localtime(&t);
                int sec = local_time->tm_sec;
                if (sec<=59) {
                    return sec;
            } return 0;
       }

        int hour24() {
            time_t t = time(0);
            tm *local_time = localtime(&t);
            int hour24 = local_time -> tm_hour;
            if (1 < hour24 and hour24 < 24){
                return hour24;
            } return 0;
    }

};

