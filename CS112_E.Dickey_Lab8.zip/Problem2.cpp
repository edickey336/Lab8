/*******************************************************
filename: Problem2.cpp
Author: Emily Dickey on 04/20/2021.
Description: Time Class Method Implementation with Struct
*******************************************************/

#include <iostream>
#include <string>
#include "DateTime2.cpp"
#include <chrono>
#include <thread>

using namespace std;

int main () {
    DateTime2 dt;

    cout << "Today's Date is: " << dt.getDateStr() << endl;
    cout << "Double check: " << dt.datetime.month << "/" << dt.datetime.day << "/" << dt.datetime.year << endl;
    cout << "The time is: " << dt.getTimeStr() << endl;
    cout << "Double check: " << dt.datetime.hour << ":" << dt.datetime.min << ":" << dt.datetime.sec << endl;
    cout << "The time in 24-hour format is: " << dt.getTimeStr24() << endl << endl;

    cout << "Now I am going to show you just hoe magical I am!" << endl;
    cout << "I am going to increment the hour by 5: "; dt+5;
    cout << dt.datetime.hour << endl;
    cout << "I am going to subtract 1: "; dt--;
    cout << dt.datetime.hour << endl;
    cout << "I am going to increment the hour by 2: "; dt+ (2);
    cout << dt.datetime.hour << endl;
    cout << "I am going to subtract the hour by 3: "; dt-(3);
    cout << dt.datetime.hour << endl;
    cout << "I am going to subtract the hour by 2: "; dt-2;
    cout << dt.datetime.hour << endl;
    cout << "I am going to increment the hour by 1: "; dt++;
    cout << dt.datetime.hour << endl;

    return 0;
}