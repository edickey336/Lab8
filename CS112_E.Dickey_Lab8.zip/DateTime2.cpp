/*******************************************************
filename: DateTime.cpp
Author: Emily Dickey on 04/15/2021.
Description: Time Class with struct and overloaded operators
*******************************************************/

#include <string>
#include <ctime>
#include <iostream>
#include "DateTime2.h"

using namespace std;

class DateTime2 {
public:
    struct dt {
        int year;
        int month;
        int day;
        int hour;
        int min;
        int sec;
    }datetime;

    void update(){
        datetime.year= cyear();
        datetime.month = cmonth();
        datetime.day=cday();
        datetime.hour=chour24();
        datetime.min=cmin();
        datetime.sec=csec();
    }

    DateTime2(){
        update();
    }

    std::string getDateStr(){
        time_t t = time(0);
        tm *local_time = localtime(&t);
        return std::to_string(1 + local_time->tm_mon) + "/" +
               std::to_string (local_time->tm_mday) + "/" +
               std::to_string(1900 + local_time->tm_year);
    }

    std:: string getTimeStr24() {
        time_t t = time(0);
        tm *local_time = localtime(&t);
        return std:: to_string(local_time->tm_hour)+ ":" +
               std::to_string (local_time->tm_min) + ":" +
               std::to_string (local_time->tm_sec);
    }

    std:: string getTimeStr() {
        time_t t = time(0);
        tm *local_time = localtime(&t);
        int hr = local_time->tm_hour;
        if (hr>12) {
            return to_string(hr - 12) + ":" +
                   to_string (local_time->tm_min) + ":" +
                   std::to_string (local_time->tm_sec) + " pm";
        } else {
            return to_string(hr) + ":" +
                   to_string (local_time->tm_min) + ":" +
                   std::to_string (local_time->tm_sec) + " am";
        }
    }

    std:: string chour() {
        time_t t = time(0);
        tm *local_time = localtime(&t);
        int hr = local_time->tm_hour;
        if (hr>12) {
            return to_string(hr - 12);
        } else {
            return to_string(hr);
        }
    }

    int cmin() {
        time_t t = time(0);
        tm *local_time = localtime(&t);
        int min = local_time->tm_min;
        if (min<=59) {
            return min;
        } return 0;
    }

    int csec() {
        time_t t = time(0);
        tm *local_time = localtime(&t);
        int sec = local_time->tm_sec;
        if (sec<=59) {
            return sec;
        } return 0;
    }

    int chour24() {
        time_t t = time(0);
        tm *local_time = localtime(&t);
        int hour24 = local_time -> tm_hour;
        if (1 < hour24 and hour24 < 24){
            return hour24;
        } return 0;
    }

    int cday() {
        time_t ttime = time(0);
        tm *local_time = localtime(&ttime);
        return local_time->tm_mday;

    }

    int cmonth() {
        time_t ttime = time(0);
        tm *local_time = localtime(&ttime);
        return 1 + local_time->tm_mon;

    }

    int cyear() {
        time_t ttime = time(0);
        tm *local_time = localtime(&ttime);
        return 1900 + local_time->tm_year;

    }


    void operator ++(){
        datetime.hour+=1;
    }

    void operator ++(int){
        datetime.hour+=1;
    }

    void operator --(){
        datetime.hour-=1;
    }

    void operator--(int){
        datetime.hour-=1;
    }

    void operator+(int num){
        datetime.hour+=num;
    }

    void operator-(int num){
        datetime.hour-=num;
    }


    };

